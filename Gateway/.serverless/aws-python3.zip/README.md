# Aula 02.2 - Usando parametros

1. No terminal do IDE criado no cloud9 execute o comando `cd ~/environment/Hackaton-exercises-serverless/02-ApiGateway/` para entrar na pasta que fara este exercicio.
2. Utilize o IDE para explorar os arquivos handler.py e serverless.yml que constam nessa pasta, eles serão utilizados para criar o lambda da api que vamos utilizar.
3. Execute um `sls deploy`
4. Para testar apenas use a url passando um nome do lugar de {usuario} EX: production/parametros/rafael